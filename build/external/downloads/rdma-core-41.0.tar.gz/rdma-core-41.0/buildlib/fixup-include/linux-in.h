/* if in.h can't be included just leave it empty */
#include <netinet/in.h>
